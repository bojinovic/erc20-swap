
```
source .env && anvil --rpc-url $RPC_URL --block-number $BLOCK_NUMBER
```

```
forge test --fork-url https://eth.llamarpc.com --block-number 19974395 -vvv
```